package com.example.projecttwoeventtrackermarcelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/*
 * Enhancement Two: This class keeps the search, filter, sort, and conflict
 * detection algorithms separate from the Android screen logic. Each method
 * accepts event data and returns a result that the Activity can display.
 */
public final class EventAlgorithms {

    public enum EventFilter {
        ALL,
        UPCOMING,
        PAST
    }

    public enum SortOrder {
        SOONEST_FIRST,
        LATEST_FIRST
    }

    private EventAlgorithms() {
        // Prevents this utility class from being instantiated.
    }

    // Performs a case-insensitive linear search through the event titles.
    public static ArrayList<Event> searchByTitle(
            List<Event> events,
            String query
    ) {
        ArrayList<Event> matches = new ArrayList<>();
        String normalizedQuery = query.trim().toLowerCase(Locale.US);

        for (Event event : events) {
            String normalizedTitle =
                    event.getTitle().toLowerCase(Locale.US);

            if (normalizedQuery.isEmpty()
                    || normalizedTitle.contains(normalizedQuery)) {
                matches.add(event);
            }
        }

        return matches;
    }

    // Uses the event date and time to separate upcoming and past events.
    public static ArrayList<Event> filterEvents(
            List<Event> events,
            EventFilter filter
    ) {
        ArrayList<Event> filteredEvents = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();

        for (Event event : events) {
            if (filter == EventFilter.ALL) {
                filteredEvents.add(event);
                continue;
            }

            LocalDateTime eventDateTime = getSafeDateTime(event);

            if (eventDateTime == null) {
                continue;
            }

            if (filter == EventFilter.UPCOMING
                    && !eventDateTime.isBefore(now)) {
                filteredEvents.add(event);
            } else if (filter == EventFilter.PAST
                    && eventDateTime.isBefore(now)) {
                filteredEvents.add(event);
            }
        }

        return filteredEvents;
    }

    // Sorts a copy so the original database results remain unchanged.
    public static ArrayList<Event> sortEvents(
            List<Event> events,
            SortOrder sortOrder
    ) {
        ArrayList<Event> sortedEvents = new ArrayList<>(events);

        Comparator<LocalDateTime> dateComparator =
                sortOrder == SortOrder.SOONEST_FIRST
                        ? Comparator.naturalOrder()
                        : Comparator.reverseOrder();

        Comparator<Event> eventComparator = Comparator
                .comparing(
                        EventAlgorithms::getSafeDateTime,
                        Comparator.nullsLast(dateComparator)
                )
                .thenComparing(
                        event -> event.getTitle().toLowerCase(Locale.US)
                );

        sortedEvents.sort(eventComparator);

        return sortedEvents;
    }

    // Checks for another event scheduled at the same date and time.
    public static boolean hasConflict(
            List<Event> events,
            Event candidate,
            int eventIdToIgnore
    ) {
        LocalDateTime candidateDateTime = getSafeDateTime(candidate);

        if (candidateDateTime == null) {
            return false;
        }

        for (Event existingEvent : events) {
            if (existingEvent.getId() == eventIdToIgnore) {
                continue;
            }

            LocalDateTime existingDateTime =
                    getSafeDateTime(existingEvent);

            if (candidateDateTime.equals(existingDateTime)) {
                return true;
            }
        }

        return false;
    }

    // Prevents one malformed older record from crashing the algorithms.
    private static LocalDateTime getSafeDateTime(Event event) {
        try {
            return event.getDateTime();
        } catch (DateTimeParseException exception) {
            return null;
        }
    }
}