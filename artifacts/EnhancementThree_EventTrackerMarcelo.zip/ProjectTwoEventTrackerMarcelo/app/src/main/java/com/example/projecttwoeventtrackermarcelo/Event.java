package com.example.projecttwoeventtrackermarcelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;

/*
 * Enhancement Two: This model keeps the values for one event together.
 * Using one Event object is safer and easier to manage than maintaining
 * separate lists for IDs, titles, dates, and times.
 */
public class Event {

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("MM/dd/uuuu HH:mm")
                    .withResolverStyle(ResolverStyle.STRICT);

    private final int id;
    private final String title;
    private final String date;
    private final String time;

    public Event(int id, String title, String date, String time) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    // Converts the text values into a value that algorithms can compare.
    public LocalDateTime getDateTime() {
        return LocalDateTime.parse(
                date + " " + time,
                DATE_TIME_FORMATTER
        );
    }

    public String getDisplayText() {
        return title + "\n" + date + " at " + time;
    }
}