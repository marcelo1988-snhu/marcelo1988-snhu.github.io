package com.example.projecttwoeventtrackermarcelo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * Enhancement Three: The database now stores salted password hashes, connects
 * every event to a user through a foreign key, and migrates the older schema
 * without dropping all saved data.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 2;

    private static final String USER_TABLE = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD_HASH = "password_hash";
    private static final String PASSWORD_SALT = "password_salt";

    private static final String EVENT_TABLE = "events";
    private static final String EVENT_ID = "id";
    private static final String EVENT_USER_ID = "user_id";
    private static final String EVENT_NAME = "event_name";
    private static final String EVENT_DATE = "event_date";
    private static final String EVENT_TIME = "event_time";

    private static final String LEGACY_USER_TABLE = "users_legacy";
    private static final String LEGACY_EVENT_TABLE = "events_legacy";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Enables the relationship between users and their events.
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTables(db);
        createIndexes(db);
    }

    /*
     * SQLiteOpenHelper performs upgrades inside a transaction. If migration
     * fails, the old database remains available instead of being partly changed.
     */
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {
        if (oldVersion < 2) {
            migrateVersionOneToTwo(db);
        }
    }

    private void createTables(SQLiteDatabase db) {
        String createUserTable =
                "CREATE TABLE " + USER_TABLE + " (" +
                        USER_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME +
                        " TEXT NOT NULL COLLATE NOCASE UNIQUE, " +
                        PASSWORD_HASH + " TEXT NOT NULL, " +
                        PASSWORD_SALT + " TEXT NOT NULL)";

        String createEventTable =
                "CREATE TABLE " + EVENT_TABLE + " (" +
                        EVENT_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        EVENT_USER_ID + " INTEGER NOT NULL, " +
                        EVENT_NAME + " TEXT NOT NULL, " +
                        EVENT_DATE + " TEXT NOT NULL, " +
                        EVENT_TIME + " TEXT NOT NULL, " +
                        "FOREIGN KEY(" + EVENT_USER_ID + ") " +
                        "REFERENCES " + USER_TABLE +
                        "(" + USER_ID + ") ON DELETE CASCADE)";

        db.execSQL(createUserTable);
        db.execSQL(createEventTable);
    }

    private void createIndexes(SQLiteDatabase db) {
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_events_user " +
                        "ON " + EVENT_TABLE +
                        "(" + EVENT_USER_ID + ")"
        );

        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_events_user_datetime " +
                        "ON " + EVENT_TABLE +
                        "(" + EVENT_USER_ID + ", " +
                        EVENT_DATE + ", " + EVENT_TIME + ")"
        );
    }

    /*
     * Converts version 1 plaintext passwords into hashes and adds the user-event
     * relationship without using the old destructive DROP TABLE upgrade.
     */
    private void migrateVersionOneToTwo(SQLiteDatabase db) {
        db.execSQL(
                "ALTER TABLE " + USER_TABLE +
                        " RENAME TO " + LEGACY_USER_TABLE
        );

        db.execSQL(
                "ALTER TABLE " + EVENT_TABLE +
                        " RENAME TO " + LEGACY_EVENT_TABLE
        );

        createTables(db);
        createIndexes(db);

        int firstUserId = migrateLegacyUsers(db);

        /*
         * Version 1 events had no owner. The old events are assigned to the
         * earliest account so that the records can still be preserved.
         */
        if (firstUserId != -1) {
            migrateLegacyEvents(db, firstUserId);
        }

        db.execSQL("DROP TABLE " + LEGACY_EVENT_TABLE);
        db.execSQL("DROP TABLE " + LEGACY_USER_TABLE);
    }

    private int migrateLegacyUsers(SQLiteDatabase db) {
        int firstUserId = -1;

        Cursor cursor = db.query(
                LEGACY_USER_TABLE,
                new String[]{USER_ID, USERNAME, "password"},
                null,
                null,
                null,
                null,
                USER_ID + " ASC"
        );

        try {
            int idColumn =
                    cursor.getColumnIndexOrThrow(USER_ID);

            int usernameColumn =
                    cursor.getColumnIndexOrThrow(USERNAME);

            int passwordColumn =
                    cursor.getColumnIndexOrThrow("password");

            while (cursor.moveToNext()) {
                int id = cursor.getInt(idColumn);
                String username = cursor.getString(usernameColumn);

                String plaintextPassword =
                        cursor.isNull(passwordColumn)
                                ? ""
                                : cursor.getString(passwordColumn);

                PasswordHasher.PasswordData passwordData =
                        PasswordHasher.createHash(plaintextPassword);

                ContentValues values = new ContentValues();
                values.put(USER_ID, id);
                values.put(USERNAME, username);
                values.put(
                        PASSWORD_HASH,
                        passwordData.getHash()
                );
                values.put(
                        PASSWORD_SALT,
                        passwordData.getSalt()
                );

                db.insertOrThrow(USER_TABLE, null, values);

                if (firstUserId == -1) {
                    firstUserId = id;
                }
            }
        } finally {
            cursor.close();
        }

        return firstUserId;
    }

    private void migrateLegacyEvents(
            SQLiteDatabase db,
            int ownerUserId
    ) {
        Cursor cursor = db.query(
                LEGACY_EVENT_TABLE,
                new String[]{
                        EVENT_ID,
                        EVENT_NAME,
                        EVENT_DATE,
                        EVENT_TIME
                },
                null,
                null,
                null,
                null,
                EVENT_ID + " ASC"
        );

        try {
            int idColumn =
                    cursor.getColumnIndexOrThrow(EVENT_ID);

            int nameColumn =
                    cursor.getColumnIndexOrThrow(EVENT_NAME);

            int dateColumn =
                    cursor.getColumnIndexOrThrow(EVENT_DATE);

            int timeColumn =
                    cursor.getColumnIndexOrThrow(EVENT_TIME);

            while (cursor.moveToNext()) {
                ContentValues values = new ContentValues();

                values.put(
                        EVENT_ID,
                        cursor.getInt(idColumn)
                );

                values.put(EVENT_USER_ID, ownerUserId);

                values.put(
                        EVENT_NAME,
                        cursor.getString(nameColumn)
                );

                values.put(
                        EVENT_DATE,
                        cursor.getString(dateColumn)
                );

                values.put(
                        EVENT_TIME,
                        cursor.getString(timeColumn)
                );

                db.insertOrThrow(EVENT_TABLE, null, values);
            }
        } finally {
            cursor.close();
        }
    }

    // Stores only the password hash and salt for a new account.
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        PasswordHasher.PasswordData passwordData =
                PasswordHasher.createHash(password);

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(
                PASSWORD_HASH,
                passwordData.getHash()
        );
        values.put(
                PASSWORD_SALT,
                passwordData.getSalt()
        );

        try {
            return db.insertOrThrow(
                    USER_TABLE,
                    null,
                    values
            ) != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    // Returns the authenticated user's database ID or -1 when login fails.
    public int authenticateUser(
            String username,
            String password
    ) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                USER_TABLE,
                new String[]{
                        USER_ID,
                        PASSWORD_HASH,
                        PASSWORD_SALT
                },
                USERNAME + " = ?",
                new String[]{username},
                null,
                null,
                null,
                "1"
        );

        try {
            if (!cursor.moveToFirst()) {
                return -1;
            }

            String storedHash = cursor.getString(
                    cursor.getColumnIndexOrThrow(PASSWORD_HASH)
            );

            String storedSalt = cursor.getString(
                    cursor.getColumnIndexOrThrow(PASSWORD_SALT)
            );

            boolean passwordMatches =
                    PasswordHasher.verifyPassword(
                            password,
                            storedHash,
                            storedSalt
                    );

            if (!passwordMatches) {
                return -1;
            }

            return cursor.getInt(
                    cursor.getColumnIndexOrThrow(USER_ID)
            );
        } finally {
            cursor.close();
        }
    }

    public boolean addEvent(
            int userId,
            String name,
            String date,
            String time
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EVENT_USER_ID, userId);
        values.put(EVENT_NAME, name);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);

        try {
            return db.insertOrThrow(
                    EVENT_TABLE,
                    null,
                    values
            ) != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    // Including the user ID prevents one account from updating another's event.
    public boolean updateEvent(
            int userId,
            int eventId,
            String name,
            String date,
            String time
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EVENT_NAME, name);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);

        int result = db.update(
                EVENT_TABLE,
                values,
                EVENT_ID + " = ? AND " +
                        EVENT_USER_ID + " = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                }
        );

        return result > 0;
    }

    // Including the user ID prevents one account from deleting another's event.
    public boolean deleteEvent(int userId, int eventId) {
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                EVENT_TABLE,
                EVENT_ID + " = ? AND " +
                        EVENT_USER_ID + " = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                }
        );

        return result > 0;
    }

    // Returns only events belonging to the authenticated account.
    public Cursor getEventsForUser(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                EVENT_TABLE,
                new String[]{
                        EVENT_ID,
                        EVENT_NAME,
                        EVENT_DATE,
                        EVENT_TIME
                },
                EVENT_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                EVENT_ID + " DESC"
        );
    }
}