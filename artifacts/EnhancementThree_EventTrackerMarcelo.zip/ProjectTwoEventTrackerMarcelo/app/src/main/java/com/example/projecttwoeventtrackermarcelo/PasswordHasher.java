package com.example.projecttwoeventtrackermarcelo;

import android.util.Base64;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/*
 * Enhancement Three: Passwords are protected with a unique random salt and
 * PBKDF2 hash before they are stored. Plaintext passwords are never saved.
 */
public final class PasswordHasher {

    private static final int SALT_LENGTH_BYTES = 16;
    private static final int HASH_LENGTH_BITS = 256;
    private static final int ITERATION_COUNT = 120_000;

    private PasswordHasher() {
        // Prevents this utility class from being instantiated.
    }

    public static PasswordData createHash(String password) {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);

        byte[] hash = deriveHash(password, salt);

        return new PasswordData(
                Base64.encodeToString(hash, Base64.NO_WRAP),
                Base64.encodeToString(salt, Base64.NO_WRAP)
        );
    }

    public static boolean verifyPassword(
            String password,
            String storedHash,
            String storedSalt
    ) {
        if (password == null || storedHash == null || storedSalt == null) {
            return false;
        }

        try {
            byte[] expectedHash =
                    Base64.decode(storedHash, Base64.NO_WRAP);

            byte[] salt =
                    Base64.decode(storedSalt, Base64.NO_WRAP);

            byte[] actualHash = deriveHash(password, salt);

            return MessageDigest.isEqual(expectedHash, actualHash);
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }

    private static byte[] deriveHash(String password, byte[] salt) {
        PBEKeySpec keySpec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                ITERATION_COUNT,
                HASH_LENGTH_BITS
        );

        try {
            SecretKeyFactory keyFactory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            return keyFactory.generateSecret(keySpec).getEncoded();
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException(
                    "Password hashing is not available.",
                    exception
            );
        } finally {
            keySpec.clearPassword();
        }
    }

    public static final class PasswordData {

        private final String hash;
        private final String salt;

        private PasswordData(String hash, String salt) {
            this.hash = hash;
            this.salt = salt;
        }

        public String getHash() {
            return hash;
        }

        public String getSalt() {
            return salt;
        }
    }
}