package com.example.projecttwoeventtrackermarcelo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String SMS_LOG_TAG = "EventTrackerSMS";

    private Button requestSmsButton;
    private Button testSmsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        requestSmsButton = findViewById(R.id.requestSmsButton);
        testSmsButton = findViewById(R.id.testSmsButton);

        // Ask the user for SMS permission.
        requestSmsButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            } else {
                Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
                Log.d(SMS_LOG_TAG, "SMS permission already granted.");
            }
        });

        // Sends a sample SMS only if permission is granted.
        testSmsButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                try {
                    SmsManager smsManager = SmsManager.getDefault();

                    String phoneNumber = "15551234567";
                    String message = "Event Tracker reminder: You have an upcoming event.";

                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                    Log.d(SMS_LOG_TAG, "SMS send attempted to " + phoneNumber + ": " + message);
                    Toast.makeText(this, "Test SMS alert sent.", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    Log.e(SMS_LOG_TAG, "SMS could not be sent.", e);
                    Toast.makeText(this, "SMS could not be sent.", Toast.LENGTH_SHORT).show();
                }

            } else {
                Log.d(SMS_LOG_TAG, "SMS permission denied. App continues without SMS.");
                Toast.makeText(this, "SMS permission denied. App still works without SMS.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Handles the user's response to the permission request.
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                Log.d(SMS_LOG_TAG, "SMS permission granted.");
            } else {
                Toast.makeText(this, "SMS permission denied. App will continue without SMS.", Toast.LENGTH_SHORT).show();
                Log.d(SMS_LOG_TAG, "SMS permission denied by user.");
            }
        }
    }
}