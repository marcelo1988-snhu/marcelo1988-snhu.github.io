package com.example.projecttwoeventtrackermarcelo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * Enhancement Three: Login now authenticates against a salted password hash
 * and passes the authenticated user ID to the event screen. This allows the
 * database to keep each user's events separate.
 */
public class MainActivity extends AppCompatActivity {

    private static final int MINIMUM_PASSWORD_LENGTH = 8;

    private EditText usernameText;
    private EditText passwordText;
    private Button loginButton;
    private Button createAccountButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        databaseHelper = new DatabaseHelper(this);
        setupButtonListeners();
    }

    private void initializeViews() {
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton =
                findViewById(R.id.createAccountButton);
    }

    private void setupButtonListeners() {
        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(
                v -> createAccount()
        );
    }

    private void loginUser() {
        String username = getUsername();
        String password = getPassword();

        if (!hasLoginInput(username, password)) {
            showMessage(
                    "Please enter username and password."
            );
            return;
        }

        int userId = databaseHelper.authenticateUser(
                username,
                password
        );

        if (userId != -1) {
            showMessage("Login successful.");
            openEventsScreen(userId);
        } else {
            showMessage("Invalid username or password.");
        }
    }

    private void createAccount() {
        String username = getUsername();
        String password = getPassword();

        if (!hasLoginInput(username, password)) {
            showMessage(
                    "Please enter username and password."
            );
            return;
        }

        if (password.length() < MINIMUM_PASSWORD_LENGTH) {
            showMessage(
                    "Password must be at least 8 characters."
            );
            return;
        }

        boolean added =
                databaseHelper.addUser(username, password);

        if (added) {
            showMessage(
                    "Account created. You can now log in."
            );
            passwordText.setText("");
        } else {
            showMessage("Username already exists.");
        }
    }

    private String getUsername() {
        return usernameText
                .getText()
                .toString()
                .trim();
    }

    // Spaces can be valid password characters, so the value is not trimmed.
    private String getPassword() {
        return passwordText
                .getText()
                .toString();
    }

    private boolean hasLoginInput(
            String username,
            String password
    ) {
        return !username.isEmpty()
                && !password.isEmpty();
    }

    private void openEventsScreen(int userId) {
        Intent intent = new Intent(
                MainActivity.this,
                EventsActivity.class
        );

        intent.putExtra(
                EventsActivity.EXTRA_USER_ID,
                userId
        );

        startActivity(intent);
    }

    private void showMessage(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }
}