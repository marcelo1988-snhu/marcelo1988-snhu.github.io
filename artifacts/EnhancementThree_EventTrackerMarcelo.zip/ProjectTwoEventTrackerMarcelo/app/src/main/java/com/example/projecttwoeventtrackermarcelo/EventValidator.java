package com.example.projecttwoeventtrackermarcelo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/*
 * Event validation remains separate from the Activity so the same rules can
 * support both the screen workflow and the date-based event algorithms.
 */
public class EventValidator {

    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("MM/dd/uuuu")
                    .withResolverStyle(ResolverStyle.STRICT);

    private static final DateTimeFormatter TIME_FORMATTER =
            DateTimeFormatter.ofPattern("HH:mm")
                    .withResolverStyle(ResolverStyle.STRICT);

    // Confirms that the user completed the required fields.
    public static boolean hasRequiredFields(
            String title,
            String date,
            String time
    ) {
        return !title.isEmpty()
                && !date.isEmpty()
                && !time.isEmpty();
    }

    // Confirms both the format and the actual calendar date.
    public static boolean isValidDateFormat(String date) {
        try {
            LocalDate.parse(date, DATE_FORMATTER);
            return true;
        } catch (DateTimeParseException exception) {
            return false;
        }
    }

    // Confirms both the format and a valid 24-hour time.
    public static boolean isValidTimeFormat(String time) {
        try {
            LocalTime.parse(time, TIME_FORMATTER);
            return true;
        } catch (DateTimeParseException exception) {
            return false;
        }
    }

    // Returns one validation message for the Activity to display.
    public static String getValidationMessage(
            String title,
            String date,
            String time
    ) {
        if (!hasRequiredFields(title, date, time)) {
            return "Please enter event title, date, and time.";
        }

        if (!isValidDateFormat(date)) {
            return "Please enter a valid date as MM/DD/YYYY.";
        }

        if (!isValidTimeFormat(time)) {
            return "Please enter a valid time as HH:MM.";
        }

        return "";
    }
}