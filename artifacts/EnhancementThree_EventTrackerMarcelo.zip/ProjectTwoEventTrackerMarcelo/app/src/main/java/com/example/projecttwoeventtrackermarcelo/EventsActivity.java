package com.example.projecttwoeventtrackermarcelo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/*
 * Enhancement Three: The screen keeps the algorithms from Enhancement Two,
 * but every database operation is now scoped to the authenticated user. This
 * prevents one account from viewing or changing another account's events.
 */
public class EventsActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "user_id";

    private EditText eventTitleText;
    private EditText eventDateText;
    private EditText eventTimeText;
    private EditText searchEventText;

    private TextView selectedEventLabel;
    private TextView resultCountLabel;
    private ListView eventListView;
    private Spinner filterSpinner;
    private Spinner sortSpinner;

    private Button saveEventButton;
    private Button updateEventButton;
    private Button deleteEventButton;
    private Button smsPermissionButton;

    private DatabaseHelper databaseHelper;

    private final ArrayList<Event> allEvents =
            new ArrayList<>();

    private final ArrayList<Event> displayedEvents =
            new ArrayList<>();

    private final ArrayList<String> eventDisplayList =
            new ArrayList<>();

    private int userId = -1;
    private int selectedEventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        initializeViews();

        userId = getIntent().getIntExtra(
                EXTRA_USER_ID,
                -1
        );

        if (userId == -1) {
            showMessage(
                    "Unable to identify the logged-in user."
            );
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        setupSpinners();
        setupListeners();
        loadEventsFromDatabase();
    }

    private void initializeViews() {
        eventTitleText =
                findViewById(R.id.eventTitleText);

        eventDateText =
                findViewById(R.id.eventDateText);

        eventTimeText =
                findViewById(R.id.eventTimeText);

        searchEventText =
                findViewById(R.id.searchEventText);

        selectedEventLabel =
                findViewById(R.id.selectedEventLabel);

        resultCountLabel =
                findViewById(R.id.resultCountLabel);

        eventListView =
                findViewById(R.id.eventListView);

        filterSpinner =
                findViewById(R.id.filterSpinner);

        sortSpinner =
                findViewById(R.id.sortSpinner);

        saveEventButton =
                findViewById(R.id.saveEventButton);

        updateEventButton =
                findViewById(R.id.updateEventButton);

        deleteEventButton =
                findViewById(R.id.deleteEventButton);

        smsPermissionButton =
                findViewById(R.id.smsPermissionButton);
    }

    private void setupSpinners() {
        String[] filterOptions = {
                "All events",
                "Upcoming",
                "Past"
        };

        ArrayAdapter<String> filterAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        filterOptions
                );

        filterAdapter.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item
        );

        filterSpinner.setAdapter(filterAdapter);

        String[] sortOptions = {
                "Soonest first",
                "Latest first"
        };

        ArrayAdapter<String> sortAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        sortOptions
                );

        sortAdapter.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item
        );

        sortSpinner.setAdapter(sortAdapter);
    }

    private void setupListeners() {
        saveEventButton.setOnClickListener(
                v -> addEvent()
        );

        updateEventButton.setOnClickListener(
                v -> updateSelectedEvent()
        );

        deleteEventButton.setOnClickListener(
                v -> deleteSelectedEvent()
        );

        smsPermissionButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    EventsActivity.this,
                    SmsPermissionActivity.class
            );

            startActivity(intent);
        });

        eventListView.setOnItemClickListener(
                (parent, view, position, id) ->
                        selectEvent(position)
        );

        searchEventText.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(
                            CharSequence text,
                            int start,
                            int count,
                            int after
                    ) {
                        // No action is required here.
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence text,
                            int start,
                            int before,
                            int count
                    ) {
                        // No action is required here.
                    }

                    @Override
                    public void afterTextChanged(
                            Editable editable
                    ) {
                        clearSelection();
                        applyCurrentView();
                    }
                }
        );

        AdapterView.OnItemSelectedListener listener =
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        clearSelection();
                        applyCurrentView();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        // The spinners always have a value.
                    }
                };

        filterSpinner.setOnItemSelectedListener(listener);
        sortSpinner.setOnItemSelectedListener(listener);
    }

    private void addEvent() {
        String title = getTitleInput();
        String date = getDateInput();
        String time = getTimeInput();

        String validationMessage =
                EventValidator.getValidationMessage(
                        title,
                        date,
                        time
                );

        if (!validationMessage.isEmpty()) {
            showMessage(validationMessage);
            return;
        }

        Event candidate =
                new Event(-1, title, date, time);

        if (EventAlgorithms.hasConflict(
                allEvents,
                candidate,
                -1
        )) {
            showMessage(
                    "Another event is already scheduled " +
                            "at this date and time."
            );
            return;
        }

        boolean added = databaseHelper.addEvent(
                userId,
                title,
                date,
                time
        );

        if (added) {
            showMessage("Event added.");
            clearEventForm();
            loadEventsFromDatabase();
        } else {
            showMessage("Event was not added.");
        }
    }

    private void updateSelectedEvent() {
        if (selectedEventId == -1) {
            showMessage(
                    "Please select an event to update."
            );
            return;
        }

        String title = getTitleInput();
        String date = getDateInput();
        String time = getTimeInput();

        String validationMessage =
                EventValidator.getValidationMessage(
                        title,
                        date,
                        time
                );

        if (!validationMessage.isEmpty()) {
            showMessage(validationMessage);
            return;
        }

        Event candidate = new Event(
                selectedEventId,
                title,
                date,
                time
        );

        if (EventAlgorithms.hasConflict(
                allEvents,
                candidate,
                selectedEventId
        )) {
            showMessage(
                    "Another event is already scheduled " +
                            "at this date and time."
            );
            return;
        }

        boolean updated = databaseHelper.updateEvent(
                userId,
                selectedEventId,
                title,
                date,
                time
        );

        if (updated) {
            showMessage("Event updated.");
            clearEventForm();
            loadEventsFromDatabase();
        } else {
            showMessage(
                    "Selected event was not found."
            );
        }
    }

    private void deleteSelectedEvent() {
        if (selectedEventId == -1) {
            showMessage(
                    "Please select an event to delete."
            );
            return;
        }

        boolean deleted = databaseHelper.deleteEvent(
                userId,
                selectedEventId
        );

        if (deleted) {
            showMessage("Event deleted.");
            clearEventForm();
            loadEventsFromDatabase();
        } else {
            showMessage(
                    "Selected event was not found."
            );
        }
    }

    private void selectEvent(int position) {
        if (position < 0
                || position >= displayedEvents.size()) {
            return;
        }

        Event selectedEvent =
                displayedEvents.get(position);

        selectedEventId = selectedEvent.getId();

        eventTitleText.setText(
                selectedEvent.getTitle()
        );

        eventDateText.setText(
                selectedEvent.getDate()
        );

        eventTimeText.setText(
                selectedEvent.getTime()
        );

        selectedEventLabel.setText(
                "Selected event: " +
                        selectedEvent.getTitle()
        );
    }

    // Loads only events owned by the authenticated user.
    private void loadEventsFromDatabase() {
        allEvents.clear();

        Cursor cursor =
                databaseHelper.getEventsForUser(userId);

        try {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String date = cursor.getString(2);
                String time = cursor.getString(3);

                allEvents.add(
                        new Event(id, title, date, time)
                );
            }
        } finally {
            cursor.close();
        }

        clearSelection();
        applyCurrentView();
    }

    private void applyCurrentView() {
        if (searchEventText == null
                || filterSpinner == null
                || sortSpinner == null) {
            return;
        }

        ArrayList<Event> searchedEvents =
                EventAlgorithms.searchByTitle(
                        allEvents,
                        searchEventText
                                .getText()
                                .toString()
                );

        ArrayList<Event> filteredEvents =
                EventAlgorithms.filterEvents(
                        searchedEvents,
                        getSelectedFilter()
                );

        ArrayList<Event> sortedEvents =
                EventAlgorithms.sortEvents(
                        filteredEvents,
                        getSelectedSortOrder()
                );

        displayedEvents.clear();
        displayedEvents.addAll(sortedEvents);

        updateEventListView();
    }

    private EventAlgorithms.EventFilter
    getSelectedFilter() {
        int position =
                filterSpinner.getSelectedItemPosition();

        if (position == 1) {
            return EventAlgorithms.EventFilter.UPCOMING;
        }

        if (position == 2) {
            return EventAlgorithms.EventFilter.PAST;
        }

        return EventAlgorithms.EventFilter.ALL;
    }

    private EventAlgorithms.SortOrder
    getSelectedSortOrder() {
        if (sortSpinner.getSelectedItemPosition() == 1) {
            return EventAlgorithms.SortOrder.LATEST_FIRST;
        }

        return EventAlgorithms.SortOrder.SOONEST_FIRST;
    }

    private void updateEventListView() {
        eventDisplayList.clear();

        for (Event event : displayedEvents) {
            eventDisplayList.add(
                    event.getDisplayText()
            );
        }

        if (eventDisplayList.isEmpty()) {
            eventDisplayList.add(
                    "No matching events."
            );
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_list_item_1,
                        eventDisplayList
                );

        eventListView.setAdapter(adapter);

        resultCountLabel.setText(
                displayedEvents.size() +
                        " event(s) shown"
        );
    }

    private void clearEventForm() {
        clearSelection();

        eventTitleText.setText("");
        eventDateText.setText("");
        eventTimeText.setText("");
    }

    private void clearSelection() {
        selectedEventId = -1;

        selectedEventLabel.setText(
                "No event selected."
        );
    }

    private String getTitleInput() {
        return eventTitleText
                .getText()
                .toString()
                .trim();
    }

    private String getDateInput() {
        return eventDateText
                .getText()
                .toString()
                .trim();
    }

    private String getTimeInput() {
        return eventTimeText
                .getText()
                .toString()
                .trim();
    }

    private void showMessage(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }
}